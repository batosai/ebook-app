import _Bar from './Bar';
export default _Bar;
