import * as create from './create';
import * as update from './update';
import * as remove from './remove';
import * as fetch from './fetch';
export { create, update, remove, fetch };
