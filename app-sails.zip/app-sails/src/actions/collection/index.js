import * as create from './create';
import * as update from './update';
import * as remove from './remove';
import * as fetchAll from './fetchAll';
export { create, update, remove, fetchAll };
